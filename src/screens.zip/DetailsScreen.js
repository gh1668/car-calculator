import React from 'react';
import { View, Text, Button, TextInput, StyleSheet, ScrollView, FlatList } from 'react-native';


export default class DetailsScreen extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      totalInterest: 0,
    }

  }

  render() {
    const { navigation } = this.props;
    const preMoney = navigation.getParam('preMoney', 'NO-ID');
    let totalmoney = navigation.getParam('totalmoney', 'NO-ID') - preMoney;
    let totalmoney1 = navigation.getParam('totalmoney', 'NO-ID') - preMoney;
    let totalmoney2 = navigation.getParam('totalmoney', 'NO-ID') - preMoney;
    const period = navigation.getParam('period', 'NO-ID');
    const installmentDay = navigation.getParam('installmentDay', 'NO-ID');
    const rate = navigation.getParam('rate', 'NO-ID') / 1000;
    const finalValue = Math.round((totalmoney * (rate / 1.2)) * (Math.pow((1 + (rate / 1.2)), installmentDay)) / (Math.pow((1 + (rate / 1.2)), installmentDay) - 1));
    const finalValue1 = (totalmoney / installmentDay)
    const way = navigation.getParam('way', 'NO-ID');
    let continueMoney = 0
    totalmoney = finalValue * installmentDay
    let numbers = Array.from({ length: installmentDay }, (e, i) => i);
    let result = numbers.map((num) => {
      continueMoney = totalmoney - finalValue
      totalmoney = continueMoney
      return continueMoney
    });
    let result1 = numbers.map((num) => {
      continueMoney = totalmoney1 - finalValue1
      totalmoney1 = continueMoney
      return continueMoney
    });
    let result2 = numbers.map((num) => {
      continueMoney = totalmoney2 - finalValue
      totalmoney2 = continueMoney
      return continueMoney
    });
    let testval = 0
    const DATA = [
      {
      },
    ];

    Itemway = ({num , way }) => {
      testval = (testval + Math.round(result[num] * 0.03))
      return (
        <View style={styles.item}>
          <Text style={styles.title2}>{numbers[num] + 1}개월차</Text>

          {way == 0 && <Text style={styles.title2}>남은 금액 : {result[num].toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {way == 1 && <Text style={styles.title2}>남은 금액 : {Math.round(result1[num]).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {way == 2 && <Text style={styles.title2}>남은 금액 : {result2[num].toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}

          {way == 0 && <Text style={styles.title2}>상환액:{finalValue.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {way == 1 && <Text style={styles.title2}>상환액:{Math.round((finalValue1 + (result1[num] * rate))).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {way == 2 && <Text style={styles.title2}>상환액:{finalValue2.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          
          {way == 0 && <Text style={styles.title2}>원금:{Math.round(finalValue - result[num] * 0.03).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {way == 1 && <Text style={styles.title2}>원금:{Math.round(finalValue1).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {way == 2 && <Text style={styles.title2}>원금:{Math.round(finalValue2 - result2[num] * 0.03).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          
          {way == 0 && <Text style={styles.title2}>이자:{Math.round(result[num] * rate).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {way == 1 && <Text style={styles.title2}>이자:{Math.round(result1[num] * rate).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {way == 2 && <Text style={styles.title2}>이자:{Math.round(result2[num] * rate).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          
          <Text style={styles.title2}>이자합계:{testval.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>   
        </View>
      );
    }

    renderHeader = (num) => {
      return (
        <View style={styles.item}>
          {num == 0 && <Text style={styles.title2}>총액 : {(finalValue * installmentDay).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {num == 1 && <Text style={styles.title2}>총액 : {(finalValue1 * installmentDay).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          {num == 2 && <Text style={styles.title2}>총액 : {(finalValue * installmentDay).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}원</Text>}
          <Text style={styles.title2}>{installmentDay}개월</Text>
        </View>
      )
    }

    return (
      <View style={styles.container}>
        <View style={styles.title}>
          <Text style={{ fontSize: 20, paddingBottom: 30, paddingLeft: 10, }}>자동차할부계산기</Text>
          <View style={{ width: "100%", borderBottomWidth: 0.5, borderColor: '#444' }} />
        </View>
        <View style={styles.content}>
          <View style={styles.elem}>
          </View>
        </View>
          <FlatList
            data={DATA}
            ListHeaderComponent={renderHeader(way)}
            renderItem={({ item }) => numbers.map(num => (<Itemway num={num} way={way}/>))}
          />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    height: 60,
    backgroundColor: 'green',
  },
  footer: {
    height: 60,
    backgroundColor: 'red',
  },
  content: {
    flex: 1,
  },
  title: {
    width: '100%',
    height: '18%',
    justifyContent: 'center',
    fontSize: 32,
    //backgroundColor: '#9aa9ff',
  },
  title2: {
    fontSize: 32,
    //backgroundColor: '#9aa9ff',
  },
  elem: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderColor: '#eee',
    borderBottomWidth: 0.5,
    padding: 5,
  },
  moneyBtn: {
    width: '100%',
    height: 40,
    flexDirection: 'row',
    borderColor: '#eee',
    justifyContent: 'center',
  },

  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userComment: {
    padding: 8,
    borderRadius: 5,
    height: 50,
    width: 60,
  },
  inputComment: {
    padding: 8,
    borderRadius: 5,
    height: 50,
    width: 100,
  },
  name: {
    paddingLeft: 10,
  },
  specialText: {
    paddingLeft: 23,
  },
  supportText: {
    padding: 7,
  },
  inputText: {
    padding: 4,
  },
  inputBtn: {
    height: 50,
  },
  footer: {
    width: '100%',
    height: '15%',
    //backgroundColor: '#1ad657',
  },
  item: {
    backgroundColor: 'skyblue',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },

});